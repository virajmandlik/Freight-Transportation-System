import { useState, useEffect } from "react";
import { ethers } from "ethers";
import { contractAbi, contractAddress } from "../Constant/constant";
import { Alert, QRCode } from "antd";

const Dashboard = ({ account, role }) => {
  const [products, setProducts] = useState([]);
  const [loading, setLoading] = useState(false);
  const [success, setSuccess] = useState(false);
  const [selectedProduct, setSelectedProduct] = useState(null);
  const [form, setForm] = useState({
    name: "",
    temperature: "",
    damageStatus: "",
    shipperLocation: "",
    productURL: "",
  });
  const [updateForm, setUpdateForm] = useState({
    temperature: "",
    damageStatus: "",
    location: "",
    productURL: "",
    receiverAddress: "",
    deliveryDetails: "",
  });

  useEffect(() => {
    fetchProducts();
    loadGoogleMaps();
  }, [account]);

  useEffect(() => {
    if (selectedProduct) {
      setUpdateForm({
        temperature: selectedProduct.temperature,
        damageStatus: selectedProduct.damageStatus,
        location: role === "Shipper" ? "" : selectedProduct.shipperLocation,
        productURL: selectedProduct.productURL || "",
        receiverAddress: "",
        deliveryDetails: selectedProduct.deliveryDetails || "",
      });
    }
  }, [selectedProduct, role]);

  async function fetchProducts() {
    if (!window.ethereum) return;
    const provider = new ethers.providers.Web3Provider(window.ethereum);
    const signer = provider.getSigner();
    const contract = new ethers.Contract(contractAddress, contractAbi, signer);
    try {
      const productCount = await contract.productCount();
      const data = [];
      for (let i = 1; i <= productCount; i++) {
        const product = await contract.getProduct(i);
        data.push({
          id: product.id.toString(),
          name: product.name,
          temperature: product.temperature,
          damageStatus: product.damageStatus,
          status: product.status,
          shipperLocation: product.shipperLocation,
          productURL: product.productURL,
          deliveryDetails: product.deliveryDetails,
        });
      }
      setProducts(data);
    } catch (err) {
      console.error("Error fetching products:", err);
    }
  }

  async function addProduct() {
    if (!window.ethereum || role !== "Producer") return;
    setLoading(true);
    const provider = new ethers.providers.Web3Provider(window.ethereum);
    const signer = provider.getSigner();
    const contract = new ethers.Contract(contractAddress, contractAbi, signer);
    try {
      const tx = await contract.addProduct(
        form.name,
        form.temperature,
        form.damageStatus,
        account,
        account,
        form.shipperLocation,
        form.productURL
      );
      await tx.wait();
      setSuccess(true);
      fetchProducts();
    } catch (err) {
      console.error("Error adding product:", err);
      alert("Error: " + err.message);
    }
    setLoading(false);
  }

  async function updateProductStatus() {
    if (!window.ethereum || !selectedProduct) return;
    setLoading(true);
    const provider = new ethers.providers.Web3Provider(window.ethereum);
    const signer = provider.getSigner();
    const contract = new ethers.Contract(contractAddress, contractAbi, signer);
    try {
      let tx;
      const productId = selectedProduct.id;

      switch (role) {
        case "Producer":
          tx = await contract.updateProducerDetails(
            productId,
            updateForm.temperature,
            updateForm.damageStatus,
            updateForm.location
          );
          break;
        case "Shipper":
          tx = await contract.updateShipperDetails(
            productId,
            updateForm.temperature,
            updateForm.damageStatus,
            updateForm.location,
            updateForm.productURL
          );
          break;
        case "Receiver":
          tx = await contract.updateReceiverDetails(
            productId,
            updateForm.temperature,
            updateForm.damageStatus,
            updateForm.deliveryDetails
          );
          break;
        default:
          throw new Error("Invalid role");
      }

      await tx.wait();
      alert("Transaction successful!");
      fetchProducts();
      setSelectedProduct(null);
    } catch (err) {
      console.error("Transaction failed:", err);
      alert("Error: " + err.message);
    }
    setLoading(false);
  }

  function loadGoogleMaps() {
    if (!window.google) {
      const script = document.createElement("script");
      script.src = `https://maps.googleapis.com/maps/api/js?key=AIzaSyCwtexJ__L-FLh8THSr7SJbd2KFvGN3_yw&callback=initMap`;
      script.async = true;
      script.defer = true;
      script.onerror = () => {
        console.error("Failed to load Google Maps script");
      };
      window.initMap = initMap;
      document.body.appendChild(script);
    } else {
      initMap();
    }
  }

  function initMap() {
    const mapElement = document.getElementById("map");
    if (!mapElement) return;

    try {
      const map = new window.google.maps.Map(mapElement, {
        center: { lat: 28.6139, lng: 77.209 },
        zoom: 13,
        mapTypeControl: true,
        streetViewControl: false,
      });

      map.addListener("click", (event) => {
        const lat = event.latLng.lat();
        const lng = event.latLng.lng();
        setForm((prev) => ({
          ...prev,
          shipperLocation: `${lat.toFixed(6)}, ${lng.toFixed(6)}`,
        }));

        // Add a marker at clicked location
        new window.google.maps.Marker({
          position: { lat, lng },
          map,
          title: "Selected Location",
        });
      });
    } catch (error) {
      console.error("Google Maps initialization error:", error);
    }
  }

  return (
    <div className="dashboard-container">
      <h2>Dashboard - {role}</h2>
      <p className="account-info">
        <strong>Account:</strong> {account}
      </p>

      {success && (
        <Alert
          message="Product added successfully!"
          type="success"
          showIcon
          closable
        />
      )}

      {role === "Producer" && (
        <div className="product-form">
          <input
            placeholder="Product Name"
            onChange={(e) => setForm({ ...form, name: e.target.value })}
          />
          <input
            placeholder="Temperature"
            onChange={(e) => setForm({ ...form, temperature: e.target.value })}
          />
          <input
            placeholder="Damage Status"
            onChange={(e) => setForm({ ...form, damageStatus: e.target.value })}
          />
          <input
            placeholder="Shipper Location"
            value={form.shipperLocation}
            readOnly
          />
          <input
            placeholder="Product URL"
            onChange={(e) => setForm({ ...form, productURL: e.target.value })}
          />
          <button onClick={addProduct} disabled={loading}>
            {loading ? "Adding..." : "Add Product"}
          </button>
        </div>
      )}

      {selectedProduct && (
        <div className="update-form">
          <h3>Update Product #{selectedProduct.id}</h3>
          <div className="form-grid">
            <input
              placeholder="Temperature"
              value={updateForm.temperature}
              onChange={(e) =>
                setUpdateForm({ ...updateForm, temperature: e.target.value })
              }
            />
            <input
              placeholder="Damage Status"
              value={updateForm.damageStatus}
              onChange={(e) =>
                setUpdateForm({ ...updateForm, damageStatus: e.target.value })
              }
            />

            {role === "Shipper" && (
              <>
                <input
                  placeholder="New Location"
                  value={updateForm.location}
                  onChange={(e) =>
                    setUpdateForm({ ...updateForm, location: e.target.value })
                  }
                />
                <input
                  placeholder="Product URL"
                  value={updateForm.productURL}
                  onChange={(e) =>
                    setUpdateForm({ ...updateForm, productURL: e.target.value })
                  }
                />
              </>
            )}

            {role === "Producer" && (
              <input
                placeholder="Shipper Location"
                value={updateForm.location}
                onChange={(e) =>
                  setUpdateForm({ ...updateForm, location: e.target.value })
                }
              />
            )}

            {role === "Receiver" && (
              <textarea
                placeholder="Delivery Details"
                value={updateForm.deliveryDetails}
                onChange={(e) =>
                  setUpdateForm({
                    ...updateForm,
                    deliveryDetails: e.target.value,
                  })
                }
                className="delivery-textarea"
              />
            )}
          </div>
          <div className="form-actions">
            <button onClick={updateProductStatus} disabled={loading}>
              {loading ? "Updating..." : "Confirm Update"}
            </button>
            <button onClick={() => setSelectedProduct(null)}>Cancel</button>
          </div>
        </div>
      )}

      <div
        id="map"
        style={{
          width: "100%",
          height: "400px",
          margin: "20px 0",
          borderRadius: "8px",
          overflow: "hidden",
        }}
        className="map-container"
      ></div>

      <table className="products-table">
        <thead>
          <tr>
            <th>ID</th>
            <th>Name</th>
            <th>Temperature</th>
            <th>Damage</th>
            <th>Status</th>
            <th>Location</th>
            <th>Delivery Details</th>
            <th>QR Code</th>
            {role === "Receiver" && <th>Action</th>}
          </tr>
        </thead>
        <tbody>
          {products.map((product, index) => (
            <tr key={index}>
              <td>{product.id}</td>
              <td>{product.name}</td>
              <td>{product.temperature}</td>
              <td>{product.damageStatus}</td>
              <td>{product.status}</td>
              <td>{product.shipperLocation}</td>
              <td>{product.deliveryDetails || "N/A"}</td>
              <td>
                {product.productURL ? (
                  <QRCode value={product.productURL} />
                ) : (
                  "No QR"
                )}
              </td>

              <td>
                <button
                  onClick={() => setSelectedProduct(product)}
                  disabled={loading}
                  className="update-btn"
                >
                  {loading ? "..." : "Update"}
                </button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>

      <button
        onClick={() => {
          localStorage.clear();
          window.location.reload();
        }}
        className="logout-btn"
      >
        Logout
      </button>
    </div>
  );
};

export default Dashboard;
